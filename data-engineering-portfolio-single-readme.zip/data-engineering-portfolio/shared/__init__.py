"""Cross-project building blocks: errors, configuration, logging and retry helpers."""
